const client = ZAFClient.init();
const openAiApiKey = "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";

async function updateSummary() {
  const convo = await getTicketConvo();
  const prompt = await getPrompt(convo);
  console.log(prompt)
  const summary = await getSummary(prompt);
  console.log(summary)
  const container = document.getElementById("container");

  container.innerText = summary;
}

async function getTicketConvo() {
  const ticketConvo = await client.get("ticket.conversation");
  return JSON.stringify(ticketConvo["ticket.conversation"]);
}

async function getPrompt(convo) {
  return `
Summarize the following customer service interaction.
Detect the customer's sentiment and extract any key dates,
places, or products in the following format.

Summary:
Customer sentiment:
Key Information:

${convo}`;
}

async function getSummary(prompt) {
  const options = {
    url: "https://api.openai.com/v1/chat/completions",
    type: "POST",
    contentType: "application/json",
    headers: {
      Authorization: `Bearer ${openAiApiKey}`,
    },
    data: JSON.stringify({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
    }),
    secure: true,
  };
  const response = await client.request(options);
  console.log("response:", response)

  return response.choices[0].message.content.trim();
}

document.addEventListener("DOMContentLoaded", function () {
  const generateReplyButton = document.getElementById("generate-reply-btn");
  const generatedReplyDiv = document.getElementById("generated-reply");

  generateReplyButton.addEventListener("click", async function () {
    try {
      await updateSummary();
      console.log("working")
      // Fetch ticket messages using Zendesk API
      // Use OpenAI to generate a reply
    } catch (error) {
      console.error("Error:", error);
      generatedReplyDiv.innerText = "Error generating reply.";
    }
  });
});
